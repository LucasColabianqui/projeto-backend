const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const app = express();
app.use(cors());
const PORT = 3000;

app.use(express.json());

const TODOS_FILE = path.join(__dirname, 'data', 'todos.json');

function readTodos() {
  if (!fs.existsSync(TODOS_FILE)) return [];
  const data = fs.readFileSync(TODOS_FILE, 'utf8');
  return data ? JSON.parse(data) : [];
}

function writeTodos(todos) {
  fs.writeFileSync(TODOS_FILE, JSON.stringify(todos, null, 2));
}

// Listar todas as tarefas, com filtro opcional
app.get('/api/todos', (req, res) => {
  const { status } = req.query;
  let todos = readTodos();
  if (status === 'completed') {
    todos = todos.filter(t => t.completed);
  } else if (status === 'pending') {
    todos = todos.filter(t => !t.completed);
  }
  res.json(todos);
});

// Adicionar tarefa
app.post('/api/todos', (req, res) => {
  const { title, priority } = req.body;
  if (!title) return res.status(400).json({ error: 'Título obrigatório' });
  const todos = readTodos();
  const newTodo = { id: Date.now(), title, completed: false, priority: priority || 'media' };
  todos.push(newTodo);
  writeTodos(todos);
  res.status(201).json(newTodo);
});

// Editar tarefa
app.put('/api/todos/:id', (req, res) => {
  const { id } = req.params;
  const { title, completed, priority } = req.body;
  const todos = readTodos();
  const todo = todos.find(t => t.id == id);
  if (!todo) return res.status(404).json({ error: 'Tarefa não encontrada' });
  if (title !== undefined) todo.title = title;
  if (completed !== undefined) todo.completed = completed;
  if (priority !== undefined) todo.priority = priority;
  writeTodos(todos);
  res.json(todo);
});

// Excluir tarefa
app.delete('/api/todos/:id', (req, res) => {
  const { id } = req.params;
  let todos = readTodos();
  const initialLength = todos.length;
  todos = todos.filter(t => t.id != id);
  if (todos.length === initialLength) return res.status(404).json({ error: 'Tarefa não encontrada' });
  writeTodos(todos);
  res.status(204).end();
});

app.listen(PORT, () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});
